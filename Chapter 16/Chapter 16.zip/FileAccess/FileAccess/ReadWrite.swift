//
//  ReadWrite.swift
//  FileAccess
//
//  Created by Jon Hoffman on 8/20/16.
//  Copyright © 2016 Jon Hoffman. All rights reserved.
//

import Foundation

struct FileAccess {
    func readWriteExample() {
        let filePath = "/Users/jonhoffman/Documents/test.file"
        
        // Write file
        let outString = "Write this text to the file"
        do {
            try outString.write(toFile: filePath, atomically: true, encoding: .utf8)
        } catch let error  {
            print("Failed writing to path: \(error)")
        }
        
        // Reading file
        var inString = ""
        do {
            inString = try String(contentsOfFile: filePath)
        } catch let error {
            print("Failed reading from path: \(error)")
        }
        print("Text Read: \(inString)")
    }
    
    
}
