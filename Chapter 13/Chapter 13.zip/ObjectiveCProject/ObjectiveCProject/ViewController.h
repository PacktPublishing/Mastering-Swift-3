//
//  ViewController.h
//  ObjectiveCProject
//
//  Created by Jon Hoffman on 2/11/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, retain) IBOutlet UITextView *messageView;
@property (nonatomic, retain) IBOutlet UITextField *nameField;


@end

