//
//  AppDelegate.h
//  ObjectiveCProject
//
//  Created by Jon Hoffman on 2/11/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

